jQuery(window).load(function($) {

	var data = {
		'action': 'getOrdersAjax',
	};

	if(jQuery('.wc-orders').length){
		setInterval(function(){
			jQuery.post(ajaxurl, data, function(response) {
				jQuery('.wc-orders > table > tbody').html(response);
			});
		},10000);


	}
});