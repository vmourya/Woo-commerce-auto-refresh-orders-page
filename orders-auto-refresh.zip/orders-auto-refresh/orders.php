<?php 
/*
Plugin Name: WC Orders
Author: Vijay Mourya
Description: WC Orders page with auto refresh 
*/

function WCOrder(){
	/* ADDING SIDE NAV MENU LINK */
	$page_title='WC Orders';
	$menu_title='WC Orders';
	$capability=1;
	$menu_slug='wc-orders';
	$function='getOrders';
	$position ='1.1';
	$icon_url=''; 
	add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position );
	WCOrder_init();
}

function WCOrder_init(){
	define( 'CTS_DIR', plugin_dir_url(__FILE__) );
	WCOrder_include_scripts();
	WCOrder_inlude_styles();
}
function WCOrder_include_scripts(){
	wp_enqueue_script('WCOrder-function', CTS_DIR .'assets/js/wcorders.js');
}
function WCOrder_inlude_styles(){
	wp_enqueue_style('WCOrder-style', CTS_DIR .'assets/css/wcorders.css');
}

function getOrders(){
	global $wpdb;

	$prefix=$wpdb->prefix;
	$query  = "SELECT {$prefix}posts.*,{$prefix}postmeta.meta_value order_total FROM {$prefix}posts,{$prefix}postmeta where {$prefix}posts.post_type = 'shop_order' AND {$prefix}postmeta.meta_key LIKE '_order_total'  AND {$prefix}posts.id = {$prefix}postmeta.post_id";

	$orders = $wpdb->get_results($query, OBJECT );
	?>
	<div class='wrap wc-orders'>
		<h1><strong>WC Orders</strong></h1>
		<table cellspacing="0">
			<thead>
				<tr>
					<th>Order</th>
					<th>Date</th>
					<th>Status</th>
					<th>Order Amount</th>
				</tr>  
			</thead>
			<tbody>
				<?php if(!empty($orders)): ?>
					<?php foreach ($orders as $order): ?>
						<tr <?php echo ($order->post_status == 'wc-processing') ? 'class="processing"' : ''; ?>>
							<td><a href="post.php?post=<?php echo $order->ID; ?>&action=edit">Order #<?php echo $order->ID; ?></a> <?php echo ($order->post_status == 'wc-processing') ? "<span class='processing'>New</span>" : ''; ?></td>
							<td><?php echo str_replace("Order &ndash; ", "",$order->post_title); ?></td>
							<td><?php echo ucfirst(str_replace("wc-", "",$order->post_status)); ?></td>
							<td><?php echo get_woocommerce_currency_symbol(). " " . $order->order_total; ?></td>
						</tr>
					<?php endforeach; ?>
				<?php else: ?>
					<tr><td></td><td>No order found.</td><td></td></tr>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
	<?php 
}

add_action('admin_menu', 'WCOrder');

add_action( 'wp_ajax_getOrdersAjax', 'getOrdersAjax' );

function getOrdersAjax() {
	global $wpdb;
	$prefix=$wpdb->prefix;
	$query  = "SELECT {$prefix}posts.*,{$prefix}postmeta.meta_value order_total FROM {$prefix}posts,{$prefix}postmeta WHERE {$prefix}posts.post_type = 'shop_order' AND {$prefix}postmeta.meta_key LIKE '_order_total'  AND {$prefix}posts.id = {$prefix}postmeta.post_id ORDER BY {$prefix}posts.id DESC";

	$orders = $wpdb->get_results($query, OBJECT ); ?>
	<?php if(!empty($orders)): ?>
		<?php foreach ($orders as $order): ?>
			<tr>
				<td><a href="post.php?post=<?php echo $order->ID; ?>&action=edit">Order #<?php echo $order->ID; ?></a> <?php echo ($order->post_status == 'wc-processing') ? "<span class='processing'>New</span>" : ''; ?></td>
				<td><?php echo str_replace("Order &ndash; ", "",$order->post_title); ?></td>
				<td><?php echo ucfirst(str_replace("wc-", "",$order->post_status)); ?></td>
				<td><?php echo get_woocommerce_currency_symbol(). " " . $order->order_total; ?></td>
			</tr>
		<?php endforeach; ?>
	<?php else: ?>
		<tr><td></td><td>No order found.</td><td></td></tr>
	<?php endif; ?>
	<?php
	wp_die(); // this is required to terminate immediately and return a proper response
}
?>